package desket.dto;

public class LanguageDTO {
	
	private String seq;			//번호(PK)
	private String language;	//언어
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	
}
