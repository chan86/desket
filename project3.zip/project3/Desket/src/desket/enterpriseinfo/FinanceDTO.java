package desket.enterpriseinfo;

public class FinanceDTO {
	
	private String seq;
	private String enterpriseinfoSeq;
	private float fifteenth;
	private float sixteenth;
	private float seventeenth;
	private float eighteenth;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getEnterpriseinfoSeq() {
		return enterpriseinfoSeq;
	}
	public void setEnterpriseinfoSeq(String enterpriseinfoSeq) {
		this.enterpriseinfoSeq = enterpriseinfoSeq;
	}
	public float getFifteenth() {
		return fifteenth;
	}
	public void setFifteenth(float fifteenth) {
		this.fifteenth = fifteenth;
	}
	public float getSixteenth() {
		return sixteenth;
	}
	public void setSixteenth(float sixteenth) {
		this.sixteenth = sixteenth;
	}
	public float getSeventeenth() {
		return seventeenth;
	}
	public void setSeventeenth(float seventeenth) {
		this.seventeenth = seventeenth;
	}
	public float getEighteenth() {
		return eighteenth;
	}
	public void setEighteenth(float eighteenth) {
		this.eighteenth = eighteenth;
	}
	
}
