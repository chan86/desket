package desket.enterpriseinfo;

public class EnterpriseListDTO {
	
	private String seq;
	private String logo;
	private String name;
	private String field;
	private String scale;
	private String establishyear;
	private String years;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getScale() {
		return scale;
	}
	public void setScale(String scale) {
		this.scale = scale;
	}
	public String getEstablishyear() {
		return establishyear;
	}
	public void setEstablishyear(String establishyear) {
		this.establishyear = establishyear;
	}
	public String getYears() {
		return years;
	}
	public void setYears(String years) {
		this.years = years;
	}
	
}
