package desket.dto;

public class EnterpriseInfoCommentDTO {
	
	private String seq;
	private String enterpriseinfoseq;
	private String content;
	private String writer;
	private String regdate;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getEnterpriseinfoseq() {
		return enterpriseinfoseq;
	}
	public void setEnterpriseinfoseq(String enterpriseinfoseq) {
		this.enterpriseinfoseq = enterpriseinfoseq;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

}
